
			Febuary 5th, 2007.

		Description of AdventureCCaw1 For 32 bit MS-Windows Console.

			Al Whinery of Maryland.

		Credits to previous authors given in game introduction.

****************************************************************************************************************

	This is the 350-point version with optional 400 and 450 levels.
	You must achieve the 350-point game to get the extra points.
	My main goals were to make the game less tedious.
	In the process I added many new features.

****************************************************************************************************************

	System requirments:
	Disk space:   At least  220 KB.
	Memory (RAM): Less than 800 KB.

****************************************************************************************************************

	Files needed in one directory to play:
	ADVENT0.DAT
	ADVENT1.DAT
	ADVENT2.DAT
	ADVENT3.DAT
	ADVENT4.DAT
	ADVENT5.DAT
	AdventureCCaw1.exe
	AdventureCCaw1_ReadMe.txt	(Don't really need this file.)

	Good commands to try:
	info
	help
	help help     -- this lists verbs and movements.
	help verb     -- where verb is in the list from the help help command.

****************************************************************************************************************

I borrowed this description from a walk through file by someone else:

The goal is to find all the treasures and take them back to the well house
before the game ends.

If you don't get killed by a little dwarf and if the pirate shows
up before you finish, you can get all the points.

When you get well into the cave you will encounter some nasty dwarves.  The
first one simply tosses an axe at you and runs away.  The axe misses.  Get the
axe; you'll need it when you see the dwarves again.  On your second encounter
with the dwarves, you'll see one or more, who will throw knives at you.  The
first salvo always misses.  Toss the axe at a dwarf, fetch it again, and keep
tossing until you have killed all the dwarves present.  You'll need to do this
each time a dwarf appears.  If you don't, you'll get killed.  (Be sure to
retrieve the axe after you have killed the last dwarf that is with you.)

Don't worry if a pirate appears and steals your treasures from you.  You'll
find them again later on.

If the pirate never appears, you probably won't make it.  When you reach the
dead end where the chest is supposed to be, you could backtrack (if you know
how) through the maze and then forward again until he appears.  If this takes
too many turns your lamp batteries will wear out before the end game, and then
it's tough beans.

****************************************************************************************************************

My intrest in this game started after I built my first computer ( Heathkit H8 with an H9 terminal )
 in the late 1970s.
Heathkit made the game available and I mastered it but I had to cheat to find out how to get the last point.

****************************************************************************************************************

Notice of good faith:
	At time of distribution, it is my best belief that this is a non-malicious program.

Disclaimer:
	This is freeware intended for enjoyment
	 and none of the authors
	 shall be held responsible for any damage caused by it's use.

Caution:
	Always scan new programs for viruses and other infections.
